package com.resourcemanager.demvirtusarm.controllers;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.resourcemanager.demvirtusarm.models.RelationalManager;
import com.resourcemanager.demvirtusarm.services.RMService;
import com.virtusa.kafkaappointmentconsumer.dto.Appointment;
//import com.virtusa.banking.appointment.models.Appointment;

//import net.minidev.json.JSONObject;

//import net.minidev.json.JSONObject;

@RestController
public class RMController {
	@Autowired
	private RMService rmService;
	//saving the Appointment details
	//@CrossOrigin("*")
	/*
	 * @PostMapping("/rmappointments/distribution/{NumberOfDestribution}")
	 * 
	 * public @ResponseBody ResponseEntity<?>
	 * addAppointment(@PathVariable("NumberOfDestribution") long Number) {
	 * List<RelationalManager>RM=rmService.getAllRelationalManager();
	 * 
	 * Collections.sort(RM,(RelationalManager RM1,RelationalManager
	 * RM2)->RM1.getNumAppointments()-RM2.getNumAppointments());
	 * RM.get(0).setNumAppointments(RM.get(0).getNumAppointments()+1); JSONObject
	 * jsonObject=new JSONObject(); jsonObject.put("message", "Update RM fail");
	 * if(this.rmService.updateAppointment(RM.get(0))!=null) return
	 * ResponseEntity.ok(this.rmService.updateAppointment(RM.get(0))); else return
	 * ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(jsonObject); }
	 */
	
	@CrossOrigin("*")
	@GetMapping("/rmappointments/{rmid}")
	
	public List<Appointment> getAppointmentsById(@PathVariable("rmid") long rmId)
	{
		
		return this.rmService.getAppointmentByRmId(rmId);
	}
	
	@CrossOrigin("*")
	@DeleteMapping("/rmappointments/{appid}")
	public void deleteAppointmentsById(@PathVariable("appid") long appId)
	{
		
		//return this.rmService.deleteAppointmentByAppId(appId);
	}
	@CrossOrigin("*")
	@PutMapping("/rmappointments/{value}")
	public void updateAppointmentsById(@PathVariable("appointment") long appId)
	{
		
		//return this.rmService.deleteAppointmentByAppId(appId);
	}
	
	
}
