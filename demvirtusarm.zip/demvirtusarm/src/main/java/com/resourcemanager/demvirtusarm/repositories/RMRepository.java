package com.resourcemanager.demvirtusarm.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.resourcemanager.demvirtusarm.models.RelationalManager;


public interface RMRepository extends JpaRepository<RelationalManager,Long>{
	@Query(value = "SELECT min(numAppointments) FROM RelationalManager")
	public int min();
	
}