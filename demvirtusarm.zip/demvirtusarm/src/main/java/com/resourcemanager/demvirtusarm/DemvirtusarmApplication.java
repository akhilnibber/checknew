package com.resourcemanager.demvirtusarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemvirtusarmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemvirtusarmApplication.class, args);
	}

}
