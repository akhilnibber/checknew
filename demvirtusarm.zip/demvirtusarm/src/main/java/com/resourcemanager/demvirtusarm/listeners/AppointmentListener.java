package com.resourcemanager.demvirtusarm.listeners;


import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;

import com.resourcemanager.demvirtusarm.facades.AppointmentStreams;
import com.resourcemanager.demvirtusarm.models.EmailTemplate;
import com.resourcemanager.demvirtusarm.models.RelationalManager;
import com.resourcemanager.demvirtusarm.services.EmailService;
import com.resourcemanager.demvirtusarm.services.RMService;
import com.virtusa.kafkaappointmentconsumer.dto.Appointment;


@EnableBinding(AppointmentStreams.class)
public class AppointmentListener {
	
	@Autowired
	private EmailTemplate emailTemplate;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private RMService rmservice;
	
	
	
	 @StreamListener(target = AppointmentStreams.INPUT)
	    public void handleBeneficiaries(@Payload Appointment appointment) {
	     System.out.println("invoked.....");   
		 System.out.println("Received appointment details:"+appointment);
		 

	System.out.println("checking to string: "+appointment.getAppointmentDate().toString());
		 
		 emailTemplate.setBody("AppointmentId: "+appointment.getAppointmentId()+" "
		 		+ "CustomerId: "+appointment.getCustomerId()+" "
				 +"RM id: "+appointment.getRmId()+" "
				 +"Appointment Date: "+appointment.getAppointmentDate()+" "
				 +"Appointment Time: "+appointment.getAppointmentTime()+" "
				 +"Appointment Type: "+appointment.getAppointmentType());
		 
		 RelationalManager rm = rmservice.getRmById(appointment.getRmId());
		 
		 
		 emailTemplate.setSendTo(rm.getEmailaddress());
		 
		// emailTemplate.setSendTo("krishnateja0612@gmail.com");
		 
		 emailTemplate.setSubject("You have a new Appointment made by Customer");
				 
		 try {
				System.out.println("Sending Simple Text Email....");
				emailService.sendTextEmail(emailTemplate);
				System.out.println("Email Sent");
			} catch (Exception ex) {
				System.out.println("Error in sending email: ");
			}
		}




		 
	    }

